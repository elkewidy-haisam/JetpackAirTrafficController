package jogamp.openal;

/**
 * ALExt implementation.
 */
public class ALExtImpl extends ALExtAbstractImpl {

}
